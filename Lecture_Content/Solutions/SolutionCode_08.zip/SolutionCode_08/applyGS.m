%%%%%%%%%%%%%%%%%%%%%%%%
% Gray-Scott model
%%%%%%%%%%%%%%%%%%%%%%%%
%
% Input
% u:        (numParticles x 1)-Vector of concentration 
%           of species u
% v:        (numParticles x 1)-Vector of concentration 
%           of species v
% a:        Scalar parameter a
% b:        Scalar parameter b
% k:        Scalar reaction rate
%
% Output
% du:       (numParticles x 1)-vector of concentration 
%           change of species u
% dv:       (numParticles x 1)-vector of concentration 
%           change of species v
%
% function [du,dv] = applyBrusselator(u,v,a,b,k)

function [du,dv] = applyGS(u,v,F,K)

du = -(u.*(v.^2)) + F*(1-u);
dv = (u.*(v.^2)) - (F+K).*v;
