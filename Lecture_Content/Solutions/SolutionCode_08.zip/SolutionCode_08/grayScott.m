%%%%%%%%%%%%%%%%%%%%%%%%
% 2D Reaction-Diffusion: The Gray-Scott model
%%%%%%%%%%%%%%%%%%%%%%%%
%

%%%%%%%%%%%%%%%%%%%%%%%%
% Global parameters

clear all;
close all;

% Computational domain
dim=2;
lBounds=0;
uBounds=2.5;

% Particles on a grid (kind=1)
kind = 1;

% Number of particles and its spacing
numParticles = 128.^2;
h = (uBounds-lBounds)/(numParticles^(1/dim)-1);
epsilon = 2*h;

% Kernel and Verlet parameter
cutoff = 3*epsilon;

% Cell list parameter
cellSide = cutoff;

% Particle volume
V = ones(numParticles^(1/dim),numParticles^(1/dim))*h^2;

% Diffusion constant
Du = 2*(10^(-5));
Dv = (10^(-5));


%%%%%%%%%%%%%%%%%%%%%%%%
% Gray Scott parameters

% Gray Scott constants
F = 0.03
K = 0.055



%%%%%%%%%%%%%%%%%%%%%%%%
% Simulation parameters
% Time step (Stability criterion for Euler dt < h^2/(2*D)
dt=3

% Simulation end time
tMax=1000*dt;

% Time vector
tVec=[dt:dt:tMax];


%%%%%%%%%%%%%%%%%%%%%%%%
% Create particles and neighbor lists

% Create particle positions
particlePos = createParticles(numParticles,dim,lBounds,uBounds,kind);

% Create cell list
[particleMat,cellList,numCells] = createCellList(particlePos,lBounds,uBounds,cellSide);

% Create Verlet list
verletList = createVerletList(particleMat,cellList,numCells,cutoff);

% Apply initial conditions, i.e. set the initial strengths u and v of
% the particles uniformly at random

particleStrength(1:numParticles,1) = 1;
particleStrength(1:numParticles,2) = 0;

% x_find = find(and(particlePos(:,1)>=1.15,particlePos(:,1)<=1.35));
% y_find = find(and(particlePos(:,2)>=1.15,particlePos(:,2)<=1.35));

x_find = find(and(particlePos(:,1)>=0,particlePos(:,1)<=2.5));
y_find = find(and(particlePos(:,2)>=0,particlePos(:,2)<=2.5));


part_id_inside = intersect(x_find,y_find);  

particleStrength(part_id_inside,1) = 0.5 + (0.005*unifrnd(-1,1,length(part_id_inside),1));
particleStrength(part_id_inside,2) = 0.25 + (0.0025*unifrnd(-1,1,length(part_id_inside),1));

particleStrength(:,1) = particleStrength(:,1).*V(:);
particleStrength(:,2) = particleStrength(:,2).*V(:);


% Add the strength to the particle matrix
particleMat = [particleMat,particleStrength];


%%%%%%%%%%%%%%%%%%%%%%%%
% Plotting the initial conditions
figure(1)
X=reshape(particleMat(:,1),sqrt(numParticles),sqrt(numParticles));
Y=reshape(particleMat(:,2),sqrt(numParticles),sqrt(numParticles));

% Concentration u
Z_u=reshape(particleMat(:,dim+2),sqrt(numParticles),sqrt(numParticles));

plotIndices = ((cutoff/h)+1):(sqrt(numParticles)-(cutoff/h));

pcolor(X(plotIndices,plotIndices),Y(plotIndices,plotIndices),Z_u(plotIndices,plotIndices))
shading interp;
title('Species u')
xlabel('x')
ylabel('y')
zlabel('concentration u')

figure(2)
% Concentration v
Z_v=reshape(particleMat(:,dim+3),sqrt(numParticles),sqrt(numParticles));
pcolor(X(plotIndices,plotIndices),Y(plotIndices,plotIndices),Z_v(plotIndices,plotIndices))
shading interp;
title('Species v')
xlabel('x')
ylabel('y')
zlabel('concentration v')
drawnow;

%dlmwrite(['U_0.dat'],Z_u(plotIndices,plotIndices),'delimiter','\t');
%dlmwrite(['V_0.dat'],Z_v(plotIndices,plotIndices),'delimiter','\t');     

timesteps = 1;


for t=tVec
t
    % Apply Diffusion step with PSE
    pseSum = applyPSE(particleMat,verletList,epsilon,2);

    u = particleMat(:,dim+2)/(h^2);
    v = particleMat(:,dim+3)/(h^2);

    [du,dv] = applyGS(u,v,F,K);

    minmaxu = [min(u),max(u)]
    
    % Apply time step to u
    %particleMat(:,dim+2) = particleMat(:,dim+2) + V(:).*(Du./epsilon^2 .* pseSum(:,1) + du)*dt;
    particleMat(:,dim+2) = particleMat(:,dim+2) + ...
            ((V(:).*Du*dt)./(epsilon^2)).*pseSum(:,1) + ...
            V(:).*du*dt;
    
    % Apply time step to v
    %particleMat(:,dim+3) = particleMat(:,dim+3) + V(:).*(Dv./epsilon^2 .* pseSum(:,2) + dv)*dt;
    particleMat(:,dim+3) = particleMat(:,dim+3) + ...
            ((V(:).*Dv*dt)./(epsilon^2)).*pseSum(:,2) + ...
            V(:).*dv*dt;
    
    
    % Apply periodic boundary conditions to u
    tempMat = reshape(particleMat(:,dim+2),sqrt(numParticles),sqrt(numParticles));
    tempMat = periodicBoundaries(tempMat,h,cutoff);
    particleMat(:,dim+2) = tempMat(:);

    % Apply periodic boundary conditions to v
    tempMat = reshape(particleMat(:,dim+3),sqrt(numParticles),sqrt(numParticles));
    tempMat = periodicBoundaries(tempMat,h,cutoff);
    particleMat(:,dim+3) = tempMat(:);

    %%%%%%%%%%%%%%%%%%%%%%%%
    % Plotting the current solution
    figure(1)
    % Concentration u
    Z_u=reshape(particleMat(:,dim+2),sqrt(numParticles),sqrt(numParticles));
    pcolor(X(plotIndices,plotIndices),Y(plotIndices,plotIndices),Z_u(plotIndices,plotIndices))
    shading interp;
    title('Species u')
    xlabel('x')
    ylabel('y')
    zlabel('concentration u')
    view(0,90)
    hold off
    
    figure(2)
    % Concentration v
    Z_v=reshape(particleMat(:,dim+3),sqrt(numParticles),sqrt(numParticles));
    pcolor(X(plotIndices,plotIndices),Y(plotIndices,plotIndices),Z_v(plotIndices,plotIndices))
    shading interp;
    title('Species v')
    xlabel('x')
    ylabel('y')
    zlabel('concentration v')
    view(0,90)
    drawnow;
    hold off
    
    
 %   if (rem(timesteps,100)==0)
 %       dlmwrite(['U_' int2str(timesteps) '.dat'],Z_u(plotIndices,plotIndices),'delimiter','\t');
 %       dlmwrite(['V_' int2str(timesteps) '.dat'],Z_v(plotIndices,plotIndices),'delimiter','\t');     
 %   end
 %   timesteps = timesteps + 1;
    
end
