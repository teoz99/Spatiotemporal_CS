%%%%%%%%%%%%%%%%%%%%%%%%
% Exercise 7 - Test the Brusselator model without diffusion
%%%%%%%%%%%%%%%%%%%%%%%%
%

%%%%%%%%%%%%%%%%%%%%%%%%
% Global parameters

%%%%%%%%%%%%%%%%%%%%%%%%
% Brusselator parameters

% Brusselator constants
a = 2
b = 6

% rate constant k
k = 1
%%%%%%%%%%%%%%%%%%%%%%%%
% Simulation parameters
% Time step
dt=0.01

% Simulation end time
tMax=20;

% Time vector
tVec=[dt:dt:tMax];

numSteps = length(tVec);
u = zeros(numSteps,1);
v = zeros(numSteps,1);
u(1) = 0.70;
v(1) = 0.04;

figure(1);

for i=2:numSteps

    [du,dv] = applyBrusselator(u(i-1),v(i-1),a,b,k);
    
    u(i) = u(i-1)+du*dt;
    v(i) = v(i-1)+dv*dt;
    
    %%%%%%%%%%%%%%%%%%%%%%%%
    % Plotting the current solution
    figure(1)

    % Concentration u and v
    plot(tVec(1:i),u(1:i),'r')
    hold on 
    plot(tVec(1:i),v(1:i),'b') 
    title('Brusselator with species u(red) and v(blue)')
    xlabel('t')
    ylabel('concentration u(red), v(blue)')
    xlim([dt tMax])
    ylim([0 8])
    grid on
    hold off
    drawnow;
end