%%%%%%%%%%%%%%%%%%%%%%%
% Exercise 7 Question (b) - 2D Reaction-Diffusion: The Brusselator model
%%%%%%%%%%%%%%%%%%%%%%%%
%

%%%%%%%%%%%%%%%%%%%%%%%%
% Global parameters

% Computational domain
dim = 2;
lBounds = 0;
uBounds = 81;

% Particles on a grid (kind=1)
kind = 1;

% Number of particles and its spacing
numParticles = 51^2;
h = (uBounds - lBounds) / (numParticles^(1/dim));
epsilon = h;


% Kernel and Verlet parameter
cutoff = 3 * epsilon;

% Cell list parameter
cellSide = cutoff;

% Particle volume
V = ones(numParticles^(1/dim), numParticles^(1/dim)) * h^2;

% Diffusion constant
Du = 2;
Dv = 16;

%%%%%%%%%%%%%%%%%%%%%%%%
% Brusselator parameters

% Brusselator constants
a = 2; %4.5
b = 6; %7.5

% rate constant k
k = 1;


%%%%%%%%%%%%%%%%%%%%%%%%
% Simulation parameters
% Time step (Stability criterion for Euler dt < h^2/(2*D)
dt = 0.01;  %h^2/(8*max(Du,Dv))

% Simulation end time
tMax = 10;

% Time vector
tVec = dt:dt:tMax;


%%%%%%%%%%%%%%%%%%%%%%%%
% Create particles and neighbor lists

% Create particle positions
particlePos = createParticles(numParticles, dim, lBounds, uBounds, kind);

% Create cell list
[particleMat, cellList, numCells] = createCellList(particlePos, lBounds, uBounds, cellSide);

% Create Verlet list
verletList = createVerletList(particleMat, cellList, numCells, cutoff);

% Apply initial conditions, i.e. set the initial strengths u and v of
% the particles uniformly at random
delta = 0.3;
particleStrength = zeros(numParticles,2);
particleStrength(:, 1) = rand(numParticles, 1) * 0.01;  %a+rand(numParticles,1).*0.3;
particleStrength(:, 2) = rand(numParticles, 1) * 0.01;  %(b/a)+rand(numParticles,1).*0.3;

% Add the strength to the particle matrix
particleMat = [particleMat, particleStrength];


%%%%%%%%%%%%%%%%%%%%%%%%
% Plotting the initial conditions
figure(1)
X = reshape(particleMat(:, 1), sqrt(numParticles), sqrt(numParticles));
Y = reshape(particleMat(:, 2), sqrt(numParticles), sqrt(numParticles));

% Concentration u
Z_u = reshape(particleMat(:, dim+2), sqrt(numParticles), sqrt(numParticles));

plotIndices = 1:51;

surf(X(plotIndices, plotIndices), Y(plotIndices, plotIndices), Z_u(plotIndices, plotIndices))
title('Species u')
xlabel('x')
ylabel('y')
zlabel('concentration u')

figure(2)
% Concentration v
Z_v=reshape(particleMat(:,dim+3),sqrt(numParticles),sqrt(numParticles));
surf(X(plotIndices, plotIndices), Y(plotIndices, plotIndices), Z_v(plotIndices, plotIndices))
title('Species v')
xlabel('x')
ylabel('y')
zlabel('concentration v')
drawnow;

conc_u = zeros(size(tVec));
conc_v = zeros(size(tVec));
iter = 0;
% compute distances
for t = tVec
    
    iter = iter+1;
    conc_u(iter) = mean( particleMat(:, dim+2) );
    conc_v(iter) = mean( particleMat(:, dim+3) );
    
    
    % Apply Diffusion step with PSE
    pseSum = applyPSE(particleMat, verletList, epsilon, 2);

    u = particleMat(:, dim + 2);
    v = particleMat(:, dim + 3);

    [du, dv] = applyBrusselator(u, v, a, b, k);

    % Apply time step to u
    particleMat(:, dim+2) = particleMat(:,dim+2) + V(:) .* (Du./epsilon^2 .* pseSum(:,1) + du) * dt;
    % Apply time step to v
    particleMat(:, dim+3) = particleMat(:,dim+3) + V(:) .* (Dv./epsilon^2 .* pseSum(:,2) + dv) * dt;

    % Apply periodic boundary conditions to u
    tempMat = reshape(particleMat(:,dim+2),sqrt(numParticles),sqrt(numParticles));
    tempMat = periodicBoundaries(tempMat,h,cutoff);
    particleMat(:,dim+2) = tempMat(:);

    % Apply periodic boundary conditions to v
    tempMat = reshape(particleMat(:,dim+3),sqrt(numParticles),sqrt(numParticles));
    tempMat = periodicBoundaries(tempMat,h,cutoff);
    particleMat(:,dim+3) = tempMat(:);

    t
    if (mod(t,0.1)==0)
        %%%%%%%%%%%%%%%%%%%%%%%%
        % Plotting the current solution
        figure(1)
        % Concentration u
        Z_u=reshape(particleMat(:,dim+2),sqrt(numParticles),sqrt(numParticles));
        surf(X(plotIndices,plotIndices),Y(plotIndices,plotIndices),Z_u(plotIndices,plotIndices),'LineStyle','none')
        title('Species U')
        xlabel('{\it x}')
        ylabel('{\it y}')
        zlabel('concentration {\it u}')
        view(0,90)
        colorbar
        hold off

        figure(2)
        % Concentration v
        Z_v=reshape(particleMat(:,dim+3),sqrt(numParticles),sqrt(numParticles));
        surf(X(plotIndices,plotIndices),Y(plotIndices,plotIndices),Z_v(plotIndices,plotIndices),'LineStyle','none')
        title('Species V')
        xlabel('{\it x}')
        ylabel('{\it y}')
        zlabel('concentration {\it v}')
        view(0,90)
        colorbar
        drawnow;
        hold off
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%
% Plotting the current solution
figure(1)
% Concentration u
Z_u=reshape(particleMat(:,dim+2),sqrt(numParticles),sqrt(numParticles));
surf(X(plotIndices,plotIndices),Y(plotIndices,plotIndices),Z_u(plotIndices,plotIndices),'LineStyle','none')
title('Species U, {\it T} = 10, no offset bw. {\it u0} and {\it v0}')
xlabel('{\it x}')
ylabel('{\it y}')
zlabel('concentration {\it u}')
view(0,90)
colorbar
hold off

figure(2)
% Concentration v
Z_v=reshape(particleMat(:,dim+3),sqrt(numParticles),sqrt(numParticles));
surf(X(plotIndices,plotIndices),Y(plotIndices,plotIndices),Z_v(plotIndices,plotIndices),'LineStyle','none')
title('Species V, {\it T} = 10, no offset bw. {\it u0} and {\it v0}')
xlabel('{\it x}')
ylabel('{\it y}')
zlabel('concentration {\it v}')
view(0,90)
colorbar
drawnow;
hold off

%%%%%%%%%%%%%%%%%%%%%%%%
% Plotting the time evolution of the concentration *averaged* over the domain
% Note that this is different from the concentration evolution in the space-free case (question part a)
% In some cases it has similar oscillatory behaviour, which may also converge to a steady state after some time.
figure(3)
% Concentration u and v
plot(tVec,conc_u,'r')
hold on 
plot(tVec,conc_v,'b') 
title({'Brusselator with diffusion: spatial average of species {\it u} (red) and {\it v} (blue)', '{\it T} = 10, no offset bw. {\it u0} and {\it v0}'})
xlabel('{\it t}')
ylabel('concentration {\it u} (red), {\it v}(blue)')
xlim([dt tMax])
ylim([0 8])
grid on
hold off


