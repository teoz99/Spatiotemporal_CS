%%%%%%%%%%%%%%%%%%%%%%%
% Exercise 7 a - Testing the Brusselator Reaction Model
%%%%%%%%%%%%%%%%%%%%%%%%
%

%%%%%%%%%%%%%%%%%%%%%%%%
% Global parameters

% Initial Concentrations
u0 = 0.7;
v0 = 0.04;

%%%%%%%%%%%%%%%%%%%%%%%%
% Brusselator parameters

% Brusselator constants
a = 2;
b = 6;

% rate constant k
k = 1;

%%%%%%%%%%%%%%%%%%%%%%%%
% Simulation parameters
% Time step
dt = 0.01;

% Simulation end time
tMax = 20;

% Time vector
tVec = dt:dt:tMax;



conc_u = zeros(1, size(tVec, 2));
conc_v = zeros(1, size(tVec, 2));


% Put the initial concentrations of u and v into the vectors
u = u0;
v = v0;
% u = a;
% v = b/(k * a);

iter = 0;
for t = tVec
    iter = iter + 1;
    
    [du,dv] = applyBrusselator(u, v, a, b, k);
    conc_u(iter) = u + du * dt;
    conc_v(iter) = v + dv * dt; 
    
    % Update the current concentration of u and v
    u = conc_u(iter);
    v = conc_v(iter);
end

%%%%%%%%%%%%%%%%%%%%%%%%
% Plotting the time evolution of the concentration
figure(1)
% Concentration u and v
plot(tVec, conc_u', 'r'); hold on 
plot(tVec, conc_v', 'b') 
title('Brusselator with species U (red) and V (blue)')
xlabel('{\it t}')
ylabel('concentration  {\it u}(red), {\it v}(blue)')
xlim([dt tMax])
ylim([0 8])
grid on
hold off
